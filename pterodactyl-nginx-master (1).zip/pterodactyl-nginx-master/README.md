# pterodactyl-nginx

self explanatory