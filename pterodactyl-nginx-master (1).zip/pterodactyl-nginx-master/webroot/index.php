<?php
echo "Hello World!";
phpinfo();